class Config:
    DB_NAME = "hospitaldb"
    DB_USER = "employee"
    DB_PASSWORD = "postgres"
    DB_HOST = "localhost"
